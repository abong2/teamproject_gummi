/* 공통요소 */
.clearfix::after {
    position: relative;
    display: block;
    width: 100%;
    clear: both;
  }
  .inner {
    position: relative;
    width: 100%;
    padding: 0px 25px;
    margin: 0 auto;
    max-width: 1600px;
    height: 100%;
  }