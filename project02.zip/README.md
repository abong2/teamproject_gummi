# 5조 비지니스 교육 플랫폼 

## 프로젝트 개요

- 팀장 : 김연우
- 팀원 : 김한빈,김혜승,장세희
- 프로젝트 기간 : 2023.09.05 ~ 2023.10.13

## 프로젝트 관련 자료

- Notion : [노션](https://www.notion.so/ec8610c695d04a22b22ec986543f941b?v=42710e46064f4744986d7da3aa6beb0e)
- 배포 URL : [배포](https://abong2.github.io/teamproject_gummi)